// Основной объект приложения
const ExhibitionApp = {
    // Массив для хранения компаний
    companies: [],
    history: [],
    // Инициализация приложения
    init() {
        // Загрузка данных из localStorage
        this.loadData();
        
        // Настройка обработчиков событий
        this.setupEventListeners();
        
        // Обновление интерфейса
        this.updateUI();
    },
    
    // Загрузка данных из localStorage
    loadData() {
        const savedData = localStorage.getItem('exhibitionCompanies');
        if (savedData) {
            this.companies = JSON.parse(savedData);
        }

        const savedHistory = localStorage.getItem('exhibitionHistory');
        if (savedHistory) {
            this.history = JSON.parse(savedHistory);
            this.updateHistoryUI();
        }
    },
    
    // Сохранение данных в localStorage
    saveData() {
        localStorage.setItem('exhibitionCompanies', JSON.stringify(this.companies));
        localStorage.setItem('exhibitionHistory', JSON.stringify(this.history));
    },
    
    //Добавление записи в историю
    addHistoryEntry(action, details, companyId = null) {
        const entry = {
            timestamp: new Date().toLocaleString(),
            action,
            details,
            companyId
        };
        
        this.history.unshift(entry); // Добавляем в начало массива
        this.saveData();
        this.updateHistoryUI();
    },

    //Обновление интерфейса истории
    updateHistoryUI() {
        const historyLog = document.getElementById('historyLog');
        historyLog.innerHTML = this.history.map(entry => `
            <div class="history-entry">
                <span class="history-time">${entry.timestamp}</span>
                ${entry.details}
            </div>
        `).join('');
    },

    // Настройка обработчиков событий
    setupEventListeners() {
        // Кнопка сохранения
        document.getElementById('saveBtn').addEventListener('click', () => this.saveCompany());
        
        // Кнопка очистки
        document.getElementById('clearBtn').addEventListener('click', () => this.clearForm());
        
        // Кнопка редактирования
        document.getElementById('editBtn').addEventListener('click', () => this.editCompany());
        
        // Кнопка удаления
        document.getElementById('deleteBtn').addEventListener('click', () => this.deleteCompany());
        
        // Кнопка сортировки
        document.getElementById('sortBtn').addEventListener('click', () => this.sortByProductCount());
        
        // Кнопка добавления свойства
        document.getElementById('addPropertyBtn').addEventListener('click', () => this.addProperty());
        
        // Кнопка удаления свойства
        document.getElementById('removePropertyBtn').addEventListener('click', () => this.removeProperty());
        
        // Выбор компании из списка
        document.getElementById('existingCompanies').addEventListener('change', (e) => {
            if (e.target.value) {
                this.loadCompanyToForm(e.target.value);
            }
        });
    },
    
    // Сохранение компании
    saveCompany() {
        const form = document.getElementById('companyForm');
        const idInput = document.getElementById('companyId');
        
        const companyData = {
            id: idInput.value || Date.now().toString(),
            name: document.getElementById('companyName').value,
            country: document.getElementById('country').value,
            email: document.getElementById('email').value,
            productCount: parseInt(document.getElementById('productCount').value),
            additionalProperties: {}
        };
        
        // Проверка заполнения обязательных полей
        if (!companyData.name || !companyData.country || !companyData.email || isNaN(companyData.productCount)) {
            alert('Пожалуйста, заполните все обязательные поля');
            return;
        }
        
        // Поиск существующей компании для обновления
        const existingIndex = this.companies.findIndex(c => c.id === companyData.id);
        
        if (existingIndex >= 0) {
            // Сохраняем дополнительные свойства при обновлении
            companyData.additionalProperties = this.companies[existingIndex].additionalProperties || {};
            this.companies[existingIndex] = companyData;
        } else {
            this.companies.push(companyData);
        }
        
        // Сохранение данных и обновление интерфейса
        this.saveData();
        this.updateUI();
        this.clearForm();
        
        alert('Компания сохранена успешно!');

        if (existingIndex >= 0) {
            this.addHistoryEntry(
                'update', 
                `Запись с ID ${companyData.id} обновлена`,
                companyData.id
            );
        } else {
            this.addHistoryEntry(
                'create', 
                `Добавлена новая запись с ID ${companyData.id}: ${companyData.name}`,
                companyData.id
            );
        }
    },
    
    // Загрузка компании в форму для редактирования
    loadCompanyToForm(id) {
        const company = this.companies.find(c => c.id === id);
        if (!company) return;
    
        // Заполняем основные поля
        document.getElementById('companyId').value = company.id;
        document.getElementById('companyName').value = company.name || '';
        document.getElementById('country').value = company.country || '';
        document.getElementById('email').value = company.email || '';
        document.getElementById('productCount').value = company.productCount || '';
    
        // Отображаем дополнительные свойства
        const propertyDisplay = document.getElementById('propertyDisplay');
        if (company.additionalProperties && Object.keys(company.additionalProperties).length > 0) {
            propertyDisplay.innerHTML = '<strong>Дополнительные свойства:</strong><br>' +
                Object.entries(company.additionalProperties)
                    .map(([key, value]) => `<b>${key}:</b> ${value}`)
                    .join('<br>');
        } else {
            propertyDisplay.innerHTML = '<em>Нет дополнительных свойств</em>';
        }
    },
    
    // Редактирование компании
    editCompany() {
        const select = document.getElementById('existingCompanies');
        if (!select.value) {
            alert('Пожалуйста, выберите компанию для редактирования');
            return;
        }
        
        this.loadCompanyToForm(select.value);
    },
    
    // Удаление компании
    deleteCompany() {
        const select = document.getElementById('existingCompanies');
        if (!select.value) {
            alert('Пожалуйста, выберите компанию для удаления');
            return;
        }

        const company = this.companies.find(c => c.id === select.value);
        if (company && confirm(`Вы уверены, что хотите удалить компанию "${company.name}"?`)) {
            this.companies = this.companies.filter(c => c.id !== select.value);
            this.addHistoryEntry(
                'delete',
                `Удалена запись: ${company.name} (ID: ${company.id})`,
                company.id
            );
            this.saveData();
            this.updateUI();
            this.clearForm();
        }
    },
    
    // Очистка формы
    clearForm() {
        document.getElementById('companyForm').reset();
        document.getElementById('companyId').value = '';
        document.getElementById('propertyValue').value = '';
        document.getElementById('propertyDisplay').textContent = '';
    },
    
    // Сортировка стран по количеству продукции
    sortByProductCount() {
        const sorted = [...this.companies]
            .sort((a, b) => b.productCount - a.productCount)
            .map(c => `${c.country}: ${c.productCount} единиц продукции`);
        
        document.getElementById('sortedCountries').innerHTML = 
            `<h4>Страны по количеству продукции:</h4><ul>${
                sorted.map(item => `<li>${item}</li>`).join('')
            }</ul>`;
    },
    
    // Добавление нового свойства
    // Полностью заменяем метод addProperty:
    addProperty() {
        const propertySelect = document.getElementById('propertySelect');
        const propertyValue = document.getElementById('propertyValue').value.trim();
        const companyId = document.getElementById('companyId').value;

        // Валидация
        if (!propertySelect.value) {
            alert('Пожалуйста, выберите свойство из списка');
            return;
        }
        if (!propertyValue) {
            alert('Пожалуйста, введите значение свойства');
            return;
        }
        if (!companyId) {
            alert('Пожалуйста, выберите компанию для редактирования');
            return;
        }

        const company = this.companies.find(c => c.id === companyId);
        if (company) {
            // Инициализируем additionalProperties если их нет
            if (!company.additionalProperties) {
                company.additionalProperties = {};
            }
            
            // Добавляем/обновляем свойство
            company.additionalProperties[propertySelect.value] = propertyValue;
            
            // Логируем в историю
            this.addHistoryEntry(
                'property_add',
                `Добавлено свойство "${propertySelect.value}": "${propertyValue}" для компании "${company.name}"`,
                company.id
            );
            
            // Сохраняем и обновляем UI
            this.saveData();
            this.updateUI();
            this.loadCompanyToForm(companyId); // Обновляем форму
            
            // Очищаем поле ввода
            document.getElementById('propertyValue').value = '';
            
            // Показываем сообщение
            alert(`Свойство "${propertySelect.value}" успешно добавлено`);
        } else {
            alert('Ошибка: компания не найдена');
        }
    },
    
    // Удаление свойства
    removeProperty() {
        const propertySelect = document.getElementById('propertySelect');
        const companyId = document.getElementById('companyId').value;
    
        if (!propertySelect.value) {
            alert('Пожалуйста, выберите свойство для удаления');
            return;
        }
        if (!companyId) {
            alert('Пожалуйста, выберите компанию');
            return;
        }
    
        const company = this.companies.find(c => c.id === companyId);
        if (company && company.additionalProperties && company.additionalProperties[propertySelect.value]) {
            // Сохраняем значение для истории
            const propertyValue = company.additionalProperties[propertySelect.value];
            
            // Удаляем свойство
            delete company.additionalProperties[propertySelect.value];
            
            // Логируем в историю
            this.addHistoryEntry(
                'property_remove',
                `Удалено свойство "${propertySelect.value}": "${propertyValue}" из компании "${company.name}"`,
                company.id
            );
            
            // Сохраняем и обновляем
            this.saveData();
            this.updateUI();
            this.loadCompanyToForm(companyId);
            
            alert(`Свойство "${propertySelect.value}" удалено`);
        } else {
            alert('У выбранной компании нет такого свойства');
        }
    },
    
    // Обновление пользовательского интерфейса
    updateUI() {
        // Обновление таблицы
        const tableBody = document.querySelector('#companiesTable tbody');
        tableBody.innerHTML = this.companies.map(company => `
            <tr>
                <td>${company.id}</td>
                <td>${company.name}</td>
                <td>${company.country}</td>
                <td>${company.email}</td>
                <td>${company.productCount}</td>
                <td>${
                    company.additionalProperties 
                        ? Object.entries(company.additionalProperties)
                            .map(([key, value]) => `${key}: ${value}`)
                            .join(', ') 
                        : ''
                }</td>
            </tr>
        `).join('');
        
        // Обновление выпадающего списка компаний
        const select = document.getElementById('existingCompanies');
        select.innerHTML = '<option value="">-- Выберите компанию --</option>' + 
            this.companies.map(company => 
                `<option value="${company.id}">${company.name} (${company.country})</option>`
            ).join('');
    }
};

// Инициализация приложения после загрузки DOM
document.addEventListener('DOMContentLoaded', () => ExhibitionApp.init());